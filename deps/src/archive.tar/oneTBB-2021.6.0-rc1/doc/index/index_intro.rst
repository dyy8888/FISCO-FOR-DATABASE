.. _index_intro:

This document contains information about |short_name|. 
It is a flexible performance library that let you break computation into parallel running tasks. 
